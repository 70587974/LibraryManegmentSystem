/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package SQLiteConnector;
import java.sql.Connection;
import java.sql.Statement;
/**
 *
 * @author 11User
 */
public class DatabaseInitializer {
    
     public static void initialize() {
        try (Connection conn = SQLiteConnector.connect();
             Statement stmt = conn.createStatement()) {

            // جدول الكتب
            stmt.execute("""
                CREATE TABLE IF NOT EXISTS books(
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    title TEXT NOT NULL,
                    author TEXT NOT NULL,
                    borrowPrice REAL NOT NULL,
                    sellPrice REAL NOT NULL,
                    copies INTEGER NOT NULL
                );
            """);

            // جدول الزبائن
            stmt.execute("""
                CREATE TABLE IF NOT EXISTS customers(
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    name TEXT NOT NULL,
                    phone TEXT NOT NULL
                );
            """);

            // جدول الاستعارة
            stmt.execute("""
                CREATE TABLE IF NOT EXISTS borrowRecords (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    customerId INTEGER,
                    bookId INTEGER,
                    date TEXT,
                    FOREIGN KEY(customerId) REFERENCES customers(id),
                    FOREIGN KEY(bookId) REFERENCES books(id)
                );
            """);

            // جدول المشتريات
            stmt.execute("""
                CREATE TABLE IF NOT EXISTS sales (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    customerId INTEGER,
                    bookId INTEGER,
                    price REAL,
                    date TEXT,
                    FOREIGN KEY(customerId) REFERENCES customers(id),
                    FOREIGN KEY(bookId) REFERENCES books(id)
                );
            """);

        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    
    
}
