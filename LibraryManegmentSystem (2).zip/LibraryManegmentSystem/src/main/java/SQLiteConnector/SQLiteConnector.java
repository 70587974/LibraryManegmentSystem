/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.SQLiteConnector to edit this template
 */
package SQLiteConnector;


import java.sql.Connection;
import java.sql.DriverManager;
/**
 *
 * @author 11User
 */
public class SQLiteConnector {
    
      private static final String URL = "jdbc:sqlite:library.db";

    public static Connection connect() {
        try {
            Class.forName("org.sqlite.JDBC");
            return DriverManager.getConnection(URL);
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }  
    
}
