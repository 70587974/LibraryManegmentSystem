/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
*/
package com.mycompany.librarymanegmentsystem;

import javax.swing.*;
import java.awt.*;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.sql.*;
import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.HashMap;
import java.time.format.DateTimeFormatter;
import java.time.LocalDateTime; 



public class LibraryGui {

    private final Map<Integer, Book> books = new HashMap<>();
    private final Map<Integer, Customer> customers = new HashMap<>();
    private final List<BorrowRecord> borrowHistory = new ArrayList<>();
    private final List<SellRecord> sellHistory = new ArrayList<>();

    private final Color BG = new Color(30, 33, 36);
    private final Color CARD = new Color(45, 48, 52);
    private final Font FONT = new Font("Segoe UI", Font.PLAIN, 16);

    private static final String DATABASE_URL = "jdbc:sqlite:library.db";
    private static final DateTimeFormatter DATE_FORMATTER = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");

    public LibraryGui() {
        try {
            Class.forName("org.sqlite.JDBC");
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
            showError(null, "SQLite JDBC driver not found! Make sure to add the JAR file to your project.");
        }
        createTables();
        loadDataFromDatabase();
    }

    
    private Connection connect() throws SQLException {
        return DriverManager.getConnection(DATABASE_URL);
    }

    private void createTables() {
        String createBooksTable = "CREATE TABLE IF NOT EXISTS books ("
                + " id INTEGER PRIMARY KEY,"
                + " title TEXT NOT NULL,"
                + " author TEXT NOT NULL,"
                + " copies INTEGER NOT NULL,"
                + " borrowPrice REAL NOT NULL,"
                + " sellPrice REAL NOT NULL,"
                + " borrowedCount INTEGER DEFAULT 0,"
                + " soldCount INTEGER DEFAULT 0"
                + ");";

        String createCustomersTable = "CREATE TABLE IF NOT EXISTS customers ("
                + " id INTEGER PRIMARY KEY,"
                + " name TEXT NOT NULL,"
                + " phone TEXT NOT NULL UNIQUE"
                + ");";

        String createBorrowTable = "CREATE TABLE IF NOT EXISTS borrow_history ("
                + " id INTEGER PRIMARY KEY AUTOINCREMENT,"
                + " book_id INTEGER NOT NULL,"
                + " customer_id INTEGER NOT NULL,"
                + " borrow_date TEXT NOT NULL,"
                + " return_date TEXT,"
                + " FOREIGN KEY(book_id) REFERENCES books(id),"
                + " FOREIGN KEY(customer_id) REFERENCES customers(id)"
                + ");";

        String createSellTable = "CREATE TABLE IF NOT EXISTS sell_history ("
                + " id INTEGER PRIMARY KEY AUTOINCREMENT,"
                + " book_id INTEGER NOT NULL,"
                + " customer_id INTEGER NOT NULL,"
                + " quantity INTEGER NOT NULL,"
                + " sell_date TEXT NOT NULL,"
                + " FOREIGN KEY(book_id) REFERENCES books(id),"
                + " FOREIGN KEY(customer_id) REFERENCES customers(id)"
                + ");";

        try (Connection conn = connect(); Statement stmt = conn.createStatement()) {
            stmt.execute(createBooksTable);
            stmt.execute(createCustomersTable);
            stmt.execute(createBorrowTable);
            stmt.execute(createSellTable);
            System.out.println("Database tables are ready.");
        } catch (SQLException e) {
            showError(null, "Error creating database tables: " + e.getMessage());
        }
    }

    private void loadDataFromDatabase() {
        books.clear();
        customers.clear();
        borrowHistory.clear();
        sellHistory.clear();

        String sqlBooks = "SELECT * FROM books";
        String sqlCustomers = "SELECT * FROM customers";
        String sqlBorrow = "SELECT * FROM borrow_history";
        String sqlSell = "SELECT * FROM sell_history";

        try (Connection conn = connect(); Statement stmt = conn.createStatement()) {
            
            ResultSet rsBooks = stmt.executeQuery(sqlBooks);
            while (rsBooks.next()) {
                Book book = new Book(
                        rsBooks.getString("title"),
                        rsBooks.getString("author"),
                        rsBooks.getInt("id"),
                        rsBooks.getInt("copies"),
                        rsBooks.getDouble("borrowPrice"),
                        rsBooks.getDouble("sellPrice")
                );
                book.setBorrowedCount(rsBooks.getInt("borrowedCount"));
                book.setSoldCount(rsBooks.getInt("soldCount"));
                books.put(book.getId(), book); 
            }

            
            ResultSet rsCustomers = stmt.executeQuery(sqlCustomers);
            while (rsCustomers.next()) {
                Customer customer = new Customer(
                        rsCustomers.getInt("id"),
                        rsCustomers.getString("name"),
                        rsCustomers.getString("phone")
                );
                customers.put(customer.getId(), customer); 
            }

          
            ResultSet rsBorrow = stmt.executeQuery(sqlBorrow);
            while (rsBorrow.next()) {
                int bookId = rsBorrow.getInt("book_id");
                int custId = rsBorrow.getInt("customer_id");
                String borrowDate = rsBorrow.getString("borrow_date");
                String returnDate = rsBorrow.getString("return_date");

                Book book = books.get(bookId);
                Customer customer = customers.get(custId);

                if (book != null && customer != null) {
                    borrowHistory.add(new BorrowRecord(book, customer, borrowDate, returnDate));
                }
            }

           
            ResultSet rsSell = stmt.executeQuery(sqlSell);
            while (rsSell.next()) {
                int bookId = rsSell.getInt("book_id");
                int custId = rsSell.getInt("customer_id");
                int quantity = rsSell.getInt("quantity");
                String sellDate = rsSell.getString("sell_date");

                Book book = books.get(bookId);
                Customer customer = customers.get(custId);

                if (book != null && customer != null) {
                    sellHistory.add(new SellRecord(book, customer, quantity, sellDate));
                }
            }

            System.out.println("Loaded data from the database.");
        } catch (SQLException e) {
            showError(null, "Error loading data from the database: " + e.getMessage());
        }
    }

    private void updateBookInDatabase(Book book) {
        String sql = "UPDATE books SET copies = ?, borrowedCount = ?, soldCount = ? WHERE id = ?";
        try (Connection conn = connect(); PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setInt(1, book.getCopies());
            pstmt.setInt(2, book.getBorrowedCount());
            pstmt.setInt(3, book.getSoldCount());
            pstmt.setInt(4, book.getId());
            pstmt.executeUpdate();
        } catch (SQLException ex) {
            showError(null, "Error updating book data in the database: " + ex.getMessage());
        }
    }

    private void insertBorrowRecord(BorrowRecord record) {
        String sql = "INSERT INTO borrow_history(book_id, customer_id, borrow_date) VALUES(?,?,?)";
        try (Connection conn = connect(); PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setInt(1, record.getBook().getId());
            pstmt.setInt(2, record.getCustomer().getId());
            pstmt.setString(3, record.getBorrowDate());
            pstmt.executeUpdate();
        } catch (SQLException ex) {
            showError(null, "Error inserting borrow record: " + ex.getMessage());
        }
    }

    private void updateBorrowRecordReturnDate(BorrowRecord record) {
        String sql = "UPDATE borrow_history SET return_date = ? WHERE book_id = ? AND customer_id = ? AND return_date IS NULL";
        try (Connection conn = connect(); PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setString(1, record.getReturnDate());
            pstmt.setInt(2, record.getBook().getId());
            pstmt.setInt(3, record.getCustomer().getId());
            pstmt.executeUpdate();
        } catch (SQLException ex) {
            showError(null, "Error updating borrow return date: " + ex.getMessage());
        }
    }

    private void insertSellRecord(SellRecord record) {
        String sql = "INSERT INTO sell_history(book_id, customer_id, quantity, sell_date) VALUES(?,?,?,?)";
        try (Connection conn = connect(); PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setInt(1, record.getBook().getId());
            pstmt.setInt(2, record.getCustomer().getId());
            pstmt.setInt(3, record.getQuantity());
            pstmt.setString(4, record.getSellDate());
            pstmt.executeUpdate();
        } catch (SQLException ex) {
            showError(null, "Error inserting sell record: " + ex.getMessage());
        }
    }

    
    public void createMainFrame() {
        JFrame frame = new JFrame("📚 Library Management System");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(760, 520);
        frame.setLocationRelativeTo(null);
        frame.getContentPane().setBackground(BG);
        frame.setLayout(new BorderLayout(0, 15));

        JLabel title = new JLabel("Library Management System", SwingConstants.CENTER);
        title.setFont(new Font("Segoe UI", Font.BOLD, 24));
        title.setForeground(Color.WHITE);
        title.setBorder(BorderFactory.createEmptyBorder(20, 0, 10, 0));
        frame.add(title, BorderLayout.NORTH);

        JPanel panel = new JPanel(new GridLayout(3, 2, 20, 20));
        panel.setBackground(BG);
        panel.setBorder(BorderFactory.createEmptyBorder(20, 60, 40, 60));

        JButton showAllBtn = createModernButton("📋 Show All");
        showAllBtn.addActionListener(e -> showAllChoice());
        panel.add(showAllBtn);

        JButton addBookBtn = createModernButton("➕ Add Book");
        addBookBtn.addActionListener(e -> openAddBookFrame());
        panel.add(addBookBtn);

        JButton addCustomerBtn = createModernButton("👤 Add Customer");
        addCustomerBtn.addActionListener(e -> openAddCustomerFrame());
        panel.add(addCustomerBtn);

        JButton borrowBtn = createModernButton("📖 Borrow Book");
        borrowBtn.addActionListener(e -> openBorrowFrame());
        panel.add(borrowBtn);

        JButton deleteBtn = createModernButton("🗑️ Delete");
        deleteBtn.addActionListener(e -> openDeleteDialog());
        panel.add(deleteBtn);

        JButton sellBtn = createModernButton("💰 Sell Book");
        sellBtn.addActionListener(e -> openSellBookFrame());
        panel.add(sellBtn);

        frame.add(panel, BorderLayout.CENTER);
        frame.setVisible(true);
    }

    private JButton createModernButton(String text) {
        JButton btn = new JButton(text);
        btn.setForeground(Color.WHITE);
        btn.setFont(new Font("Segoe UI", Font.BOLD, 16));
        btn.setFocusPainted(false);
        btn.setBorderPainted(false);
        btn.setContentAreaFilled(false);
        btn.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        btn.setPreferredSize(new Dimension(240, 60));
        btn.addMouseListener(new MouseAdapter() {
            public void mouseEntered(MouseEvent e) {
                btn.setBackground(new Color(70, 140, 250));
                btn.setOpaque(true);
            }
            public void mouseExited(MouseEvent e) {
                btn.setOpaque(false);
            }
        });
        return btn;
    }

    private JFrame createFormFrame(String title, int rows) {
        JFrame frame = new JFrame(title);
        frame.setSize(520, 140 + rows * 55);
        frame.setLocationRelativeTo(null);
        frame.getContentPane().setBackground(CARD);
        frame.setLayout(new GridLayout(rows, 2, 12, 12));
        frame.setResizable(false);
        return frame;
    }

    private JTextField createTextField() {
        JTextField field = new JTextField();
        field.setBackground(new Color(60, 63, 65));
        field.setForeground(Color.WHITE);
        field.setCaretColor(Color.WHITE);
        field.setBorder(BorderFactory.createEmptyBorder(6, 8, 6, 8));
        field.setFont(FONT);
        return field;
    }

    private JLabel createLabel(String text) {
        JLabel label = new JLabel(text);
        label.setForeground(Color.WHITE);
        label.setFont(FONT);
        return label;
    }

    private void showError(Component parent, String message) {
        JOptionPane.showMessageDialog(parent, message, "❌ Error", JOptionPane.ERROR_MESSAGE);
    }

    

    private void openAddBookFrame() {
        JFrame frame = createFormFrame("Add Book", 7);
        JTextField titleField = createTextField(), authorField = createTextField(), idField = createTextField(), copiesField = createTextField(), borrowField = createTextField(), sellField = createTextField();

        frame.add(createLabel("Title:")); frame.add(titleField);
        frame.add(createLabel("Author:")); frame.add(authorField);
        frame.add(createLabel("Book ID:")); frame.add(idField);
        frame.add(createLabel("Copies:")); frame.add(copiesField);
        frame.add(createLabel("Borrow Price:")); frame.add(borrowField);
        frame.add(createLabel("Sell Price:")); frame.add(sellField);

        JButton addCopiesBtn = createModernButton("➕ Add Copies");
        JButton saveBtn = createModernButton("💾 Save");
        JButton cancelBtn = createModernButton("✖ Cancel");
        cancelBtn.addActionListener(e -> frame.dispose());

        JPanel rightPanel = new JPanel(new GridLayout(1, 2, 8, 8));
        rightPanel.setBackground(CARD);
        rightPanel.add(saveBtn);
        rightPanel.add(cancelBtn);
        frame.add(addCopiesBtn);
        frame.add(rightPanel);

        saveBtn.addActionListener(e -> {
            String title, author;
            int id, copies;
            double borrowPrice, sellPrice;
            try {
                title = titleField.getText().trim();
                author = authorField.getText().trim();
                id = Integer.parseInt(idField.getText().trim());
                copies = Integer.parseInt(copiesField.getText().trim());
                borrowPrice = Double.parseDouble(borrowField.getText().trim());
                sellPrice = Double.parseDouble(sellField.getText().trim());

                if (title.isEmpty() || author.isEmpty()) throw new IllegalArgumentException("Title and Author cannot be empty.");
                if (id < 0 || copies < 0 || borrowPrice < 0 || sellPrice < 0) throw new IllegalArgumentException("Numeric values cannot be negative.");
                if (books.containsKey(id)) {
                    showError(frame, "A book with this ID already exists.");
                    return;
                }
                
                if (title.isEmpty() || author.isEmpty()) throw new IllegalArgumentException("Title and Author cannot be empty.");

                if (!title.matches("[a-zA-Z\\s]+")) throw new IllegalArgumentException("Title must contain only letters and spaces.");
                if (!author.matches("[a-zA-Z\\s]+")) throw new IllegalArgumentException("Author must contain only letters and spaces.");


            } catch (Exception ex) {
                showError(frame, "Invalid data: " + ex.getMessage());
                return;
            }

            String sql = "INSERT INTO books(id, title, author, copies, borrowPrice, sellPrice) VALUES(?,?,?,?,?,?)";
            try (Connection conn = connect(); PreparedStatement pstmt = conn.prepareStatement(sql)) {
                pstmt.setInt(1, id);
                pstmt.setString(2, title);
                pstmt.setString(3, author);
                pstmt.setInt(4, copies);
                pstmt.setDouble(5, borrowPrice);
                pstmt.setDouble(6, sellPrice);
                pstmt.executeUpdate();

                books.put(id, new Book(title, author, id, copies, borrowPrice, sellPrice));
                JOptionPane.showMessageDialog(frame, "✅ Book saved successfully!");
                frame.dispose();
            } catch (SQLException ex) {
                showError(frame, "Database error: " + ex.getMessage());
            }
        });

        addCopiesBtn.addActionListener(e -> {
            try {
                int id = Integer.parseInt(idField.getText().trim());
                int amount = Integer.parseInt(copiesField.getText().trim());
                if (amount <= 0) throw new IllegalArgumentException("The amount to add must be positive.");

                Book book = books.get(id);
                if (book == null) {
                    showError(frame, "Book not found.");
                    return;
                }

                String sql = "UPDATE books SET copies = copies + ? WHERE id = ?";
                try (Connection conn = connect(); PreparedStatement pstmt = conn.prepareStatement(sql)) {
                    pstmt.setInt(1, amount);
                    pstmt.setInt(2, id);
                    pstmt.executeUpdate();

                    book.addCopies(amount);
                    JOptionPane.showMessageDialog(frame, "✅ Copies added successfully!");
                    frame.dispose();
                } catch (SQLException ex) {
                    showError(frame, "Error updating the database: " + ex.getMessage());
                }
            } catch (Exception ex) {
                showError(frame, "Invalid data: " + ex.getMessage());
            }
        });

        frame.setVisible(true);
    }

    private void openAddCustomerFrame() {
        JFrame frame = createFormFrame("Add Customer", 4);
        JTextField idField = createTextField(), nameField = createTextField(), phoneField = createTextField();

        frame.add(createLabel("Customer ID:")); frame.add(idField);
        frame.add(createLabel("Name:")); frame.add(nameField);
        frame.add(createLabel("Phone (8 digits):")); frame.add(phoneField);

        JButton saveBtn = createModernButton("💾 Save");
        JButton cancelBtn = createModernButton("✖ Cancel");
        cancelBtn.addActionListener(e -> frame.dispose());
        frame.add(cancelBtn);
        frame.add(saveBtn);

        saveBtn.addActionListener(e -> {
            int id;
            String name, phone;
            try {
                id = Integer.parseInt(idField.getText().trim());
                name = nameField.getText().trim();
                phone = phoneField.getText().trim();
                if (name.isEmpty() || !phone.matches("\\d{8}")) throw new IllegalArgumentException("Invalid customer data (ensure phone is 8 digits).");
                if (customers.containsKey(id)) {
                    showError(frame, "Customer with this ID already exists.");
                    return;
                }
                if (customers.values().stream().anyMatch(c -> c.getphoneNumber().equals(phone))) {
                    showError(frame, "Customer with this phone number already exists.");
                    return;
                }
                 if (!name.matches("[a-zA-Z\\s]+")) 
                    throw new IllegalArgumentException("Customer Name must contain only letters and spaces.");
                if (id < 0) 
                    throw new IllegalArgumentException("Customer ID cannot be negative.");
                
            } catch (Exception ex) {
                showError(frame, "Invalid data: " + ex.getMessage());
                return;
            }

            String sql = "INSERT INTO customers(id, name, phone) VALUES(?,?,?)";
            try (Connection conn = connect(); PreparedStatement pstmt = conn.prepareStatement(sql)) {
                pstmt.setInt(1, id);
                pstmt.setString(2, name);
                pstmt.setString(3, phone);
                pstmt.executeUpdate();

                Customer newCustomer = new Customer(id, name, phone);
                customers.put(id, newCustomer);
                JOptionPane.showMessageDialog(frame, "✅ Customer added successfully!");
                frame.dispose();
            } catch (SQLException ex) {
                showError(frame, "Database error: " + ex.getMessage());
            }
        });
        frame.setVisible(true);
    }

     private void openDeleteDialog() {
        String[] options = {"Delete Book", "Delete Customer", "Cancel"};
        int choice = JOptionPane.showOptionDialog(null, "Choose delete type", "Delete", JOptionPane.DEFAULT_OPTION, JOptionPane.QUESTION_MESSAGE, null, options, options[0]);

        if (choice == 0) { // Delete Book
            String input = JOptionPane.showInputDialog("Enter Book ID to delete:");
            if (input == null) return;
            try {
                int id = Integer.parseInt(input.trim());
                
                // VALIDATION: Check for active borrow records for this book
                if (borrowHistory.stream().anyMatch(r -> r.getBook().getId() == id && r.getReturnDate() == null)) {
                    showError(null, "Cannot delete book. It is currently borrowed by a customer.");
                    return;
                }
                
                String sql = "DELETE FROM books WHERE id = ?";
                try (Connection conn = connect(); PreparedStatement pstmt = conn.prepareStatement(sql)) {
                    pstmt.setInt(1, id);
                    if (pstmt.executeUpdate() > 0) {
                        books.remove(id);
                        JOptionPane.showMessageDialog(null, "✅ Book deleted successfully.");
                    } else {
                        showError(null, "Book not found.");
                    }
                }
            } catch (Exception ex) {
                showError(null, "Error: " + ex.getMessage());
            }
        } else if (choice == 1) { // Delete Customer
            String input = JOptionPane.showInputDialog("Enter Customer ID to delete:");
            if (input == null) return;
            try {
                int id = Integer.parseInt(input.trim());
                // VALIDATION: Check for active borrow records (return_date IS NULL)
                if (borrowHistory.stream().anyMatch(r -> r.getCustomer().getId() == id && r.getReturnDate() == null)) {
                    showError(null, "Cannot delete customer with active borrow records.");
                    return;
                }
                String sql = "DELETE FROM customers WHERE id = ?";
                try (Connection conn = connect(); PreparedStatement pstmt = conn.prepareStatement(sql)) {
                    pstmt.setInt(1, id);
                    if (pstmt.executeUpdate() > 0) {
                        customers.remove(id);
                        // Remove all history records for this customer (optional, but good for cleanup)
                        borrowHistory.removeIf(r -> r.getCustomer().getId() == id);
                        sellHistory.removeIf(r -> r.getCustomer().getId() == id);
                        JOptionPane.showMessageDialog(null, "✅ Customer deleted successfully.");
                    } else {
                        showError(null, "Customer not found.");
                    }
                }
            } catch (Exception ex) {
                showError(null, "Error: " + ex.getMessage());
            }
        }
    }


    private void openBorrowFrame() {
        if (customers.isEmpty() || books.isEmpty()) {
            showError(null, "⚠️ No books or customers available. Please add them first.");
            return;
        }
        try {
            String custIdStr = JOptionPane.showInputDialog("Enter Customer ID:");
            if (custIdStr == null) return;
            int custId = Integer.parseInt(custIdStr.trim());

            String bookIdStr = JOptionPane.showInputDialog("Enter Book ID:");
            if (bookIdStr == null) return;
            int bookId = Integer.parseInt(bookIdStr.trim());

            Customer customer = customers.get(custId);
            if (customer == null) throw new IllegalArgumentException("Customer not found");

            Book book = books.get(bookId);
            if (book == null) throw new IllegalArgumentException("Book not found");

            if (book.getCopies() <= 0) throw new IllegalArgumentException("No copies available");

         
            if (borrowHistory.stream().anyMatch(r -> r.getCustomer().getId() == custId && r.getBook().getId() == bookId && r.getReturnDate() == null)) {
                throw new IllegalArgumentException("Customer already has an active borrow record for this book.");
            }

            book.setCopies(book.getCopies() - 1);
            book.incrementBorrowedCount();
            updateBookInDatabase(book); 

            String borrowDate = LocalDateTime.now().format(DATE_FORMATTER);
            BorrowRecord record = new BorrowRecord(book, customer, borrowDate, null);
            borrowHistory.add(record);
            insertBorrowRecord(record); 

            JOptionPane.showMessageDialog(null, "✅ Book borrowed successfully!");
        } catch (Exception ex) {
            showError(null, "Invalid data or error: " + ex.getMessage());
        }
    }

    private void openReturnFrame() {
        if (borrowHistory.isEmpty()) {
            showError(null, "⚠️ No active borrow records to return.");
            return;
        }
        try {
            String custIdStr = JOptionPane.showInputDialog("Enter Customer ID:");
            if (custIdStr == null) return;
            int custId = Integer.parseInt(custIdStr.trim());

            String bookIdStr = JOptionPane.showInputDialog("Enter Book ID:");
            if (bookIdStr == null) return;
            int bookId = Integer.parseInt(bookIdStr.trim());

            Book book = books.get(bookId);
            if (book == null) throw new IllegalArgumentException("Book not found");

           
            BorrowRecord record = borrowHistory.stream()
                    .filter(r -> r.getCustomer().getId() == custId && r.getBook().getId() == bookId && r.getReturnDate() == null)
                    .findFirst()
                    .orElseThrow(() -> new IllegalArgumentException("No active borrow record found for this customer and book."));

            book.setCopies(book.getCopies() + 1);
            updateBookInDatabase(book); 

            String returnDate = LocalDateTime.now().format(DATE_FORMATTER);
            record.setReturnDate(returnDate);
            updateBorrowRecordReturnDate(record); 

            JOptionPane.showMessageDialog(null, "✅ Book returned successfully!");
        } catch (Exception ex) {
            showError(null, "Invalid data or error: " + ex.getMessage());
        }
    }

    private void openSellBookFrame() {
        if (customers.isEmpty() || books.isEmpty()) {
            showError(null, "⚠️ No books or customers available. Please add them first.");
            return;
        }
        JFrame frame = createFormFrame("Sell Book", 4);
        JTextField customerField = createTextField(), bookField = createTextField(), qtyField = createTextField();

        frame.add(createLabel("Customer ID:")); frame.add(customerField);
        frame.add(createLabel("Book ID:")); frame.add(bookField);
        frame.add(createLabel("Quantity:")); frame.add(qtyField);

        JButton sellBtn = createModernButton("💰 Sell");
        JButton cancelBtn = createModernButton("✖ Cancel");
        cancelBtn.addActionListener(e -> frame.dispose());
        frame.add(cancelBtn);
        frame.add(sellBtn);

        sellBtn.addActionListener(e -> {
            try {
                int custId = Integer.parseInt(customerField.getText().trim());
                int bookId = Integer.parseInt(bookField.getText().trim());
                int qty = Integer.parseInt(qtyField.getText().trim());

                if (qty <= 0) throw new IllegalArgumentException("Quantity must be positive.");

                Customer customer = customers.get(custId);
                if (customer == null) throw new IllegalArgumentException("Customer not found");

                Book book = books.get(bookId);
                if (book == null) throw new IllegalArgumentException("Book not found");

                if (book.getCopies() < qty) throw new IllegalArgumentException("Not enough copies available!");

                book.setCopies(book.getCopies() - qty);
                book.incrementSoldCount(qty);
                updateBookInDatabase(book); // Update the database

                String sellDate = LocalDateTime.now().format(DATE_FORMATTER);
                SellRecord sell = new SellRecord(book, customer, qty, sellDate);
                sellHistory.add(sell);
                insertSellRecord(sell); // Insert into database

                JOptionPane.showMessageDialog(frame, "✅ Book sold successfully!");
                frame.dispose();
            } catch (Exception ex) {
                showError(frame, "Invalid data or error: " + ex.getMessage());
            }
        });
        frame.setVisible(true);
    }

    private void showAllChoice() {
        String[] options = {"Show All Books & History", "Show All Customers & History", "Cancel"};
        int choice = JOptionPane.showOptionDialog(null, "What would you like to view?", "Show All", JOptionPane.DEFAULT_OPTION, JOptionPane.QUESTION_MESSAGE, null, options, options[0]);

        if (choice == 0) {
            showAllBooks();
        } else if (choice == 1) {
            showAllCustomers();
        }
    }

    private void showAllBooks() {
        JFrame frame = new JFrame("Library Books & History (Optimized Display)");
        frame.setSize(800, 600);
        frame.setLocationRelativeTo(null);
        frame.getContentPane().setBackground(BG);
        frame.setLayout(new BorderLayout());

        JTextArea displayArea = new JTextArea();
        displayArea.setEditable(false);
        displayArea.setBackground(CARD);
        displayArea.setForeground(Color.WHITE);
        displayArea.setFont(new Font("Consolas", Font.PLAIN, 14));
        displayArea.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));

        StringBuilder sb = new StringBuilder();
        sb.append("===================================================================\n");
        sb.append("                         📚 ALL BOOKS\n");
        sb.append("===================================================================\n");

        for (Book book : books.values()) {
            sb.append(book.toString()).append("\n");
            sb.append(String.format("   Total Borrowed: %d | Total Sold: %d\n", book.getBorrowedCount(), book.getSoldCount()));

            boolean hasHistory = false;

            // Display Borrow History for this book
            List<BorrowRecord> bookBorrows = borrowHistory.stream()
                    .filter(r -> r.getBook().getId() == book.getId())
                    .toList();
            if (!bookBorrows.isEmpty()) {
                sb.append("   --- Borrow History ---\n");
                for (BorrowRecord r : bookBorrows) {
                    sb.append(String.format("   [BORROW] %s | Customer: %s (ID: %d) | Status: %s\n",
                            r.getBorrowDate(), r.getCustomer().getName(), r.getCustomer().getId(),
                            r.getReturnDate() == null ? "Active" : "Returned on " + r.getReturnDate()));
                }
                hasHistory = true;
            }

            // Display Sell History for this book
            List<SellRecord> bookSells = sellHistory.stream()
                    .filter(r -> r.getBook().getId() == book.getId())
                    .toList();
            if (!bookSells.isEmpty()) {
                sb.append("   --- Sell History ---\n");
                for (SellRecord r : bookSells) {
                    sb.append(String.format("   [SELL] %s | Customer: %s (ID: %d) | Qty: %d\n",
                            r.getSellDate(), r.getCustomer().getName(), r.getCustomer().getId(), r.getQuantity()));
                }
                hasHistory = true;
            }

            if (!hasHistory) {
                sb.append("   (No transaction history found for this book)\n");
            }

            sb.append("-------------------------------------------------------------------\n");
        }

        displayArea.setText(sb.toString());
        frame.add(new JScrollPane(displayArea), BorderLayout.CENTER);
        frame.setVisible(true);
    }

    private void showAllCustomers() {
        JFrame frame = new JFrame("All Customers & History (Optimized Display)");
        frame.setSize(800, 600);
        frame.setLocationRelativeTo(null);
        frame.getContentPane().setBackground(BG);
        frame.setLayout(new BorderLayout());

        JTextArea displayArea = new JTextArea();
        displayArea.setEditable(false);
        displayArea.setBackground(CARD);
        displayArea.setForeground(Color.WHITE);
        displayArea.setFont(new Font("Consolas", Font.PLAIN, 14));
        displayArea.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));

        StringBuilder sb = new StringBuilder();
        sb.append("===================================================================\n");
        sb.append("                         👤 ALL CUSTOMERS\n");
        sb.append("===================================================================\n");

        for (Customer customer : customers.values()) {
            sb.append(customer.toString()).append("\n");

            boolean hasHistory = false;

            // Display Borrow History for this customer
            List<BorrowRecord> custBorrows = borrowHistory.stream()
                    .filter(r -> r.getCustomer().getId() == customer.getId())
                    .toList();
            if (!custBorrows.isEmpty()) {
                sb.append("   --- Borrow History ---\n");
                for (BorrowRecord r : custBorrows) {
                    sb.append(String.format("   [BORROW] %s | Book: %s (ID: %d) | Status: %s\n",
                            r.getBorrowDate(), r.getBook().getTitle(), r.getBook().getId(),
                            r.getReturnDate() == null ? "Active" : "Returned on " + r.getReturnDate()));
                }
                hasHistory = true;
            }

            // Display Sell History for this customer
            List<SellRecord> custSells = sellHistory.stream()
                    .filter(r -> r.getCustomer().getId() == customer.getId())
                    .toList();
            if (!custSells.isEmpty()) {
                sb.append("   --- Purchase History ---\n");
                for (SellRecord r : custSells) {
                    sb.append(String.format("   [PURCHASE] %s | Book: %s (ID: %d) | Qty: %d\n",
                            r.getSellDate(), r.getBook().getTitle(), r.getBook().getId(), r.getQuantity()));
                }
                hasHistory = true;
            }

            if (!hasHistory) {
                sb.append("   (No transaction history found for this customer)\n");
            }

            sb.append("-------------------------------------------------------------------\n");
        }

        displayArea.setText(sb.toString());
        frame.add(new JScrollPane(displayArea), BorderLayout.CENTER);
        frame.setVisible(true);
    } }


    
