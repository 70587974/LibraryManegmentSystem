/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.librarymanegmentsystem;

import javax.swing.SwingUtilities;

public class LibraryManegmentSystem {
    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            LibraryGui gui = new LibraryGui();
            gui.createMainFrame();
        });
    }
}




         
    
