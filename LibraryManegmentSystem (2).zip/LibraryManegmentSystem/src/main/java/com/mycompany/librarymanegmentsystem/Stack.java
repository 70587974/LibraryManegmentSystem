/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.librarymanegmentsystem;

/**
 *
 * @author 11User
 */
public class Stack {
    
    int top;
    int S[];
    
    
    public Stack(int size){
        S=new int[size];
        top=-1;
    }
    
    public boolean isEmpty(){
        return top ==-1;
    }
    
    public boolean isFull(){
        return top==S.length-1;
    }
   /* 
    public void display(){
    
        if(isEmpty()){
            System.out.println("Stack is Empty");
        }
        else{
            System.out.println("Stakc from top -> bottom");
            Stack temp = new Stack(Stacksize());
        }
}
    
*/

    public void push(int x){
        if(isFull()){
            throw new IllegalStateException("The Stack is Full");
        }
        else if(isEmpty()){
            top++;
            S[top]=x;
        }
        else{
            top++;
            S[top]=x;
        }
    }
    
    public int pop(){
        if(isEmpty()){
              throw new IllegalStateException("The Stack is Full");        }
        else{
            int Popped=S[top];
            top--;
            return Popped;
        } 
      
    }
    
    public int Peek(){
        if(isEmpty()){
            throw new IllegalStateException("The Stack is Empty");
        }
        else{
            return S[top];
        }
    }
    
    public int StackSize(){
        return top+1; 
    }

    
}
