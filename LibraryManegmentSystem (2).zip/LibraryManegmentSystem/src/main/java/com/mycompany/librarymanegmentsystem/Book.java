/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.librarymanegmentsystem;

public class Book {
    
    private String title, author;
    private int id, copies;
    private double borrowPrice, sellPrice;
    private int borrowedCount = 0;
    private int soldCount = 0;

    public Book(String title, String author, int id, int copies, double borrowPrice, double sellPrice) {
        this.title = title;
        this.author = author;
        this.id = id;
        this.copies = copies;
        this.borrowPrice = borrowPrice;
        this.sellPrice = sellPrice;
    }

    
    public String getTitle() { return title; }
    public String getAuthor() { return author; }
    public int getId() { return id; }
    public int getCopies() { return copies; }
    public double getBorrowPrice() { return borrowPrice; }
    public double getSellPrice() { return sellPrice; }
    public int getBorrowedCount() { return borrowedCount; }
    public int getSoldCount() { return soldCount; }

   
    public void setCopies(int copies) { this.copies = copies; }
    public void setBorrowedCount(int borrowedCount) { this.borrowedCount = borrowedCount; }
    public void setSoldCount(int soldCount) { this.soldCount = soldCount; }
    public void incrementBorrowedCount() { this.borrowedCount++; }
    public void incrementSoldCount(int qty) { this.soldCount += qty; }
    public void addCopies(int amount) { this.copies += amount; }

    @Override
    public String toString() {
        return String.format("ID: %d | %s by %s | Copies: %d | Borrow: $%.2f | Sell: $%.2f",
                id, title, author, copies, borrowPrice, sellPrice);
    }
}