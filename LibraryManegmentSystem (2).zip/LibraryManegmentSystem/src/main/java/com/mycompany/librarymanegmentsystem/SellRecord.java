/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.librarymanegmentsystem;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

public class SellRecord {
    private Book book;
    private Customer customer;
    private int quantity;
    private String sellDate;

    public SellRecord(Book book, Customer customer, int quantity, String sellDate) {
        this.book = book;
        this.customer = customer;
        this.quantity = quantity;
        this.sellDate = sellDate;
    }

    // Getters
    public Book getBook() { return book; }
    public Customer getCustomer() { return customer; }
    public int getQuantity() { return quantity; }
    public String getSellDate() { return sellDate; }

    @Override
    public String toString() {
        return String.format("Sold: %s | Book: %s (ID: %d) | Qty: %d | Customer: %s (ID: %d)",
                sellDate, book.getTitle(), book.getId(), quantity, customer.getName(), customer.getId());
    }
}
