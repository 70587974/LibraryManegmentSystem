/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.librarymanegmentsystem;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

public class BorrowRecord {
    private Book book;
    private Customer customer;
    private String borrowDate;
    private String returnDate;

    public BorrowRecord(Book book, Customer customer, String borrowDate, String returnDate) {
        this.book = book;
        this.customer = customer;
        this.borrowDate = borrowDate;
        this.returnDate = returnDate;
    }

    // Getters
    public Book getBook() { return book; }
    public Customer getCustomer() { return customer; }
    public String getBorrowDate() { return borrowDate; }
    public String getReturnDate() { return returnDate; }

    public void setReturnDate(String returnDate) { this.returnDate = returnDate; }

    @Override
    public String toString() {
        String status = returnDate == null ? " (Active)" : " (Returned)";
        return String.format("Borrowed: %s | Book: %s (ID: %d) | Customer: %s (ID: %d)%s",
                borrowDate, book.getTitle(), book.getId(), customer.getName(), customer.getId(), status);
    }
}
