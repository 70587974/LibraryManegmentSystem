/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.librarymanegmentsystem;

public class Customer {
     private int id;
    private String name;
    private String phoneNumber;

    public Customer(int id, String name, String phoneNumber) {
        this.id = id;
        this.name = name;
        this.phoneNumber = phoneNumber;
    }

    // Getters
    public int getId() { return id; }
    public String getName() { return name; }
    public String getphoneNumber() { return phoneNumber; }

    @Override
    public String toString() {
        return String.format("%d - %s | Phone: %s", id, name, phoneNumber);
    }
}
